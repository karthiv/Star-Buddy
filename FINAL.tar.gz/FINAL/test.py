# -*- coding: utf-8 -*-

from Testing import *
t = Testing()
t.init()
t.setTime("22h02m0s")
t.setRef(1 , "2h31m49s", "89º15'51''", "22h04m20s", "0º27'09''", "36º49'17''")
t.setRef(2 , "18h36m56s", "38º47'03''", "22h05m07s", "78º10'04''", "70º05'19''")
#t.goto1("100","160")
t.goto("18h03m48s", "24º23'00''", "22h06m52s")
#t.goto("13h17m55s", "8º29'04''", "22h07m51s")
